package jiang719;

import java.util.ArrayList;

public class Test {
    int n = 0;
    double m = 0;

    Test (int x, double y) {
        n = x;
        double t = y + x;
        m = t;
    }
}
